const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

canvas.width = 960;
canvas.height = 540;


// ============================
// GAME STATE
// ============================

let gameStarted = false;

let heartsCollected = 0;

let health = 100;

let enemiesDefeated = 0;

let questComplete = false;

let dialogueOpen = false;

let dialogueIndex = 0;

let currentDialogue = [];


// ============================
// PLAYER
// ============================

const player = {

    x: 480,
    y: 270,

    width: 28,
    height: 38,

    speed: 4,

    attackCooldown: 0

};


// ============================
// KEYS
// ============================

const keys = {};

document.addEventListener(
    "keydown",
    event => {

        keys[event.key.toLowerCase()] = true;

        if (
            event.key === " " &&
            gameStarted &&
            !dialogueOpen
        ) {

            attack();
        }

    }
);


document.addEventListener(
    "keyup",
    event => {

        keys[event.key.toLowerCase()] = false;

    }
);


// ============================
// WORLD
// ============================

const world = {

    width: 1800,

    height: 1200

};


// ============================
// CAMERA
// ============================

const camera = {

    x: 0,

    y: 0

};


// ============================
// WALLS
// ============================

const walls = [

    {x:200,y:150,width:400,height:30},

    {x:900,y:150,width:400,height:30},

    {x:300,y:500,width:300,height:30},

    {x:1000,y:500,width:400,height:30},

    {x:500,y:800,width:600,height:30},

    {x:150,y:950,width:300,height:30},

    {x:1250,y:900,width:300,height:30}

];


// ============================
// TREES
// ============================

const trees = [

    {x:100,y:100},
    {x:750,y:100},
    {x:1450,y:120},

    {x:100,y:700},
    {x:750,y:650},
    {x:1500,y:650},

    {x:200,y:1100},
    {x:900,y:1050},
    {x:1550,y:1050}

];


// ============================
// HEARTS
// ============================

const hearts = [

    {x:250,y:300,collected:false},

    {x:700,y:350,collected:false},

    {x:1150,y:300,collected:false},

    {x:1400,y:700,collected:false},

    {x:800,y:950,collected:false}

];


// ============================
// ENEMIES
// ============================

const enemies = [

    {
        x:600,
        y:300,
        width:30,
        height:30,
        health:2,
        alive:true
    },

    {
        x:1100,
        y:350,
        width:30,
        height:30,
        health:2,
        alive:true
    },

    {
        x:1350,
        y:750,
        width:30,
        height:30,
        health:3,
        alive:true
    }

];


// ============================
// NPC
// ============================

const npc = {

    x:1500,

    y:300,

    width:30,

    height:40

};


// ============================
// COLLISION
// ============================

function collision(a,b) {

    return (

        a.x < b.x + b.width &&

        a.x + a.width > b.x &&

        a.y < b.y + b.height &&

        a.y + a.height > b.y

    );

}


// ============================
// MOVE PLAYER
// ============================

function movePlayer() {

    if(dialogueOpen) return;


    let oldX = player.x;
    let oldY = player.y;


    if(keys["w"])
        player.y -= player.speed;

    if(keys["s"])
        player.y += player.speed;

    for(const wall of walls) {

        if(collision(player,wall)) {

            player.y = oldY;

        }

    }


    oldY = player.y;


    if(keys["a"])
        player.x -= player.speed;

    if(keys["d"])
        player.x += player.speed;


    for(const wall of walls) {

        if(collision(player,wall)) {

            player.x = oldX;

        }

    }


    player.x = Math.max(
        0,
        Math.min(
            world.width-player.width,
            player.x
        )
    );


    player.y = Math.max(
        0,
        Math.min(
            world.height-player.height,
            player.y
        )
    );

}


// ============================
// CAMERA
// ============================

function updateCamera() {

    camera.x =
        player.x -
        canvas.width / 2;

    camera.y =
        player.y -
        canvas.height / 2;


    camera.x = Math.max(
        0,
        Math.min(
            world.width-canvas.width,
            camera.x
        )
    );


    camera.y = Math.max(
        0,
        Math.min(
            world.height-canvas.height,
            camera.y
        )
    );

}


// ============================
// DRAW GROUND
// ============================

function drawGround() {

    ctx.fillStyle = "#4f913e";

    ctx.fillRect(
        0,
        0,
        world.width,
        world.height
    );


    // مسیر اصلی

    ctx.fillStyle = "#c5a26b";

    ctx.fillRect(
        0,
        250,
        world.width,
        100
    );


    ctx.fillRect(
        420,
        0,
        100,
        world.height
    );

}


// ============================
// DRAW TREE
// ============================

function drawTree(x,y) {

    ctx.fillStyle = "#68401f";

    ctx.fillRect(
        x+13,
        y+25,
        18,
        45
    );


    ctx.fillStyle = "#1f642c";

    ctx.beginPath();

    ctx.arc(
        x+22,
        y+20,
        32,
        0,
        Math.PI*2
    );

    ctx.fill();

}


// ============================
// DRAW WALLS
// ============================

function drawWalls() {

    for(const wall of walls) {

        ctx.fillStyle = "#54352c";

        ctx.fillRect(
            wall.x,
            wall.y,
            wall.width,
            wall.height
        );

    }

}


// ============================
// DRAW PLAYER
// ============================

function drawPlayer() {

    const x = player.x;
    const y = player.y;


    // مو

    ctx.fillStyle = "#171717";

    ctx.fillRect(
        x+4,
        y,
        20,
        10
    );


    // صورت

    ctx.fillStyle = "#e7b18b";

    ctx.fillRect(
        x+6,
        y+9,
        16,
        15
    );


    // لباس

    ctx.fillStyle = "#202020";

    ctx.fillRect(
        x+3,
        y+23,
        22,
        14
    );


    // پا

    ctx.fillStyle = "#111";

    ctx.fillRect(
        x+4,
        y+37,
        8,
        5
    );

    ctx.fillRect(
        x+17,
        y+37,
        8,
        5
    );

}


// ============================
// DRAW HEART
// ============================

function drawHeart(x,y) {

    ctx.font = "28px Arial";

    ctx.fillText(
        "❤️",
        x,
        y
    );

}


// ============================
// DRAW ENEMY
// ============================

function drawEnemy(enemy) {

    if(!enemy.alive)
        return;


    ctx.fillStyle = "#7138a8";

    ctx.fillRect(
        enemy.x,
        enemy.y,
        enemy.width,
        enemy.height
    );


    ctx.fillStyle = "red";

    ctx.fillRect(
        enemy.x+6,
        enemy.y+8,
        6,
        6
    );

    ctx.fillRect(
        enemy.x+18,
        enemy.y+8,
        6,
        6
    );

}


// ============================
// DRAW NPC
// ============================

function drawNPC() {

    ctx.fillStyle = "#ff8bdc";

    ctx.fillRect(
        npc.x,
        npc.y,
        npc.width,
        npc.height
    );


    ctx.font = "14px Arial";

    ctx.fillStyle = "white";

    ctx.fillText(
        "Sana",
        npc.x-5,
        npc.y-10
    );

}


// ============================
// COLLECT HEARTS
// ============================

function collectHearts() {

    for(const heart of hearts) {

        if(heart.collected)
            continue;


        const target = {

            x: heart.x,

            y: heart.y,

            width: 25,

            height: 25

        };


        if(collision(player,target)) {

            heart.collected = true;

            heartsCollected++;

            document.getElementById(
                "hearts"
            ).textContent = heartsCollected;


            showMessage(
                "❤️ یه قلب پیدا کردی!"
            );


            if(heartsCollected >= 5) {

                questComplete = true;

                updateQuest();

            }

        }

    }

}


// ============================
// ENEMY AI
// ============================

function updateEnemies() {

    for(const enemy of enemies) {

        if(!enemy.alive)
            continue;


        const dx =
            player.x - enemy.x;

        const dy =
            player.y - enemy.y;


        const distance =
            Math.sqrt(
                dx*dx + dy*dy
            );


        if(distance < 220) {

            enemy.x +=
                dx / distance * 1.2;

            enemy.y +=
                dy / distance * 1.2;

        }


        if(
            collision(player,enemy)
        ) {

            health -= .15;

            document.getElementById(
                "health"
            ).textContent =
                Math.max(
                    0,
                    Math.floor(health)
                );


            if(health <= 0) {

                gameOver();

            }

        }

    }

}


// ============================
// ATTACK
// ============================

function attack() {

    if(player.attackCooldown > 0)
        return;


    player.attackCooldown = 25;


    const attackBox = {

        x: player.x-15,

        y: player.y-15,

        width: player.width+30,

        height: player.height+30

    };


    for(const enemy of enemies) {

        if(
            enemy.alive &&
            collision(
                attackBox,
                enemy
            )
        ) {

            enemy.health--;


            showMessage(
                "⚔️ ضربه خورد!"
            );


            if(enemy.health <= 0) {

                enemy.alive = false;

                enemiesDefeated++;

                document.getElementById(
                    "enemyCount"
                ).textContent =
                    enemiesDefeated;

            }

        }

    }

}


// ============================
// NPC INTERACTION
// ============================

function checkNPC() {

    if(
        collision(
            player,
            {
                x:npc.x-30,
                y:npc.y-30,
                width:90,
                height:100
            }
        )
    ) {

        if(
            keys["e"] &&
            !dialogueOpen
        ) {

            startDialogue();

        }

    }

}


// ============================
// DIALOGUE
// ============================

function startDialogue() {

    dialogueOpen = true;

    currentDialogue = [

        {
            name:"ثنا",

            text:
            "بالاخره رسیدی! 👀"
        },

        {
            name:"ثنا",

            text:
            "فکر کردی اینجا آخر مأموریته؟ 😌"
        },

        {
            name:"ثنا",

            text:
            "اول باید پنج تا قلب پیدا می‌کردی."
        },

        {
            name:"ثنا",

            text:
            "اگه همه‌شون رو پیدا کردی، پس آماده‌ای..."
        }

    ];


    dialogueIndex = 0;

    showDialogue();

}


function showDialogue() {

    const dialogue =
        currentDialogue[
            dialogueIndex
        ];


    document.getElementById(
        "dialogueName"
    ).textContent =
        dialogue.name;


    document.getElementById(
        "dialogueText"
    ).textContent =
        dialogue.text;


    document.getElementById(
        "dialogue"
    ).classList.remove(
        "hidden"
    );

}


document.getElementById(
    "dialogueNext"
).onclick = () => {

    dialogueIndex++;


    if(
        dialogueIndex >=
        currentDialogue.length
    ) {

        dialogueOpen = false;

        document.getElementById(
            "dialogue"
        ).classList.add(
            "hidden"
        );

        return;

    }


    showDialogue();

};


// ============================
// QUEST
// ============================

function updateQuest() {

    const quest =
        document.getElementById(
            "quest"
        );

    quest.classList.remove(
        "hidden"
    );


    if(!questComplete) {

        document.getElementById(
            "questText"
        ).textContent =
            `پنج قلب پیدا کن: ${heartsCollected}/5`;

    } else {

        document.getElementById(
            "questText"
        ).textContent =
            "همه قلب‌ها پیدا شدند! حالا برو پیش ثنا 💗";

    }

}


// ============================
// MESSAGE
// ============================

let messageTimeout;


function showMessage(text) {

    const message =
        document.getElementById(
            "message"
        );


    message.textContent = text;

    message.style.display = "block";


    clearTimeout(messageTimeout);


    messageTimeout =
        setTimeout(() => {

            message.style.display =
                "none";

        },2000);

}


// ============================
// GAME OVER
// ============================

function gameOver() {

    gameStarted = false;


    document.getElementById(
        "gameOver"
    ).classList.remove(
        "hidden"
    );

}


// ============================
// ENDING
// ============================

function checkEnding() {

    if(
        questComplete &&
        collision(
            player,
            {
                x:npc.x-20,
                y:npc.y-20,
                width:70,
                height:80
            }
        )
    ) {

        document.getElementById(
            "ending"
        ).classList.remove(
            "hidden"
        );

        gameStarted = false;

    }

}


// ============================
// PROPOSAL
// ============================

document.getElementById(
    "proposalButton"
).onclick = () => {

    document.getElementById(
        "ending"
    ).classList.add(
        "hidden"
    );


    document.getElementById(
        "proposal"
    ).classList.remove(
        "hidden"
    );

};


function yesAnswer() {

    document.getElementById(
        "proposal"
    ).classList.add(
        "hidden"
    );


    document.getElementById(
        "yesEnding"
    ).classList.remove(
        "hidden"
    );

}


function noAnswer() {

    document.getElementById(
        "proposal"
    ).classList.add(
        "hidden"
    );


    document.getElementById(
        "noEnding"
    ).classList.remove(
        "hidden"
    );

}


// ============================
// DRAW EVERYTHING
// ============================

function draw() {

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    ctx.save();


    ctx.translate(
        -camera.x,
        -camera.y
    );


    drawGround();

    drawWalls();


    for(const tree of trees) {

        drawTree(
            tree.x,
            tree.y
        );

    }


    for(const heart of hearts) {

        if(!heart.collected) {

            drawHeart(
                heart.x,
                heart.y
            );

        }

    }


    for(const enemy of enemies) {

        drawEnemy(enemy);

    }


    drawNPC();

    drawPlayer();


    ctx.restore();

}


// ============================
// UPDATE
// ============================

function update() {

    if(!gameStarted)
        return;


    movePlayer();

    updateEnemies();

    collectHearts();

    checkNPC();

    checkEnding();

    updateCamera();


    if(
        player.attackCooldown > 0
    ) {

        player.attackCooldown--;

    }

}


// ============================
// GAME LOOP
// ============================

function gameLoop() {

    update();

    draw();

    requestAnimationFrame(
        gameLoop
    );

}


gameLoop();


// ============================
// START
// ============================

document.getElementById(
    "startButton"
).onclick = () => {

    gameStarted = true;


    document.getElementById(
        "startScreen"
    ).classList.add(
        "hidden"
    );


    updateQuest();

};